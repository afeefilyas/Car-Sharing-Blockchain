# Car sharing blockchain 
Proof of concept system to renting cars with use of smart contracts. 
### Prerequisites
You do not need any extra libraries, the only thing is installed Python3.
### Running 
We have provided example with renting one car for three days. 
To run example:
```
git clone https://github.com/jakubrog/car-sharing-blockchain/
cd car-sharing-blockchain
python main.py
```